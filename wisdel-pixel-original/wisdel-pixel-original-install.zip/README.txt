Codex desktop installation: 1536x2288 v2 atlas.
73 animation/look frames plus one neutral fallback cell (row 0, column 6), copied from approved idle frame 0.
All original animation frames and source artifacts are preserved.
